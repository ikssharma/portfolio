// bloging webpage js

console.log("lets started");
document.querySelector('.cross-read').style.display='none';
document.querySelector('.blogitem').addEventListener("click",()=>{
    document.querySelector('.sidebar-read').classList.toggle('sidebargo-read');
    if(document.querySelector('.sidebar-read').classList.contains('sidebargo-read')){
        document.querySelector('.btn-info-sm-c').style.display='inline'
        document.querySelector('.cross-read').style.display='none'
        document.querySelector('.blogcontainer').style.display='inliner'
    }
    else{
        document.querySelector('.btn-info-sm-c').style.display='none'
        document.querySelector('.blogcontainer').style.display='none'
        setTimeout(()=>{
        document.querySelector('.cross-read').style.display='inline'
    },400);
    }
})
document.querySelector('.cross-read').style.display='none';
document.querySelector('.hamburger-read').addEventListener("click",()=>{
    document.querySelector('.sidebar-read').classList.toggle('sidebargo-read');
    if(document.querySelector('.sidebar-read').classList.contains('sidebargo-read')){
        document.querySelector('.btn-info-sm-c').style.display='inline'
        document.querySelector('.cross-read').style.display='none'
        document.querySelector('.blogcontainer').style.display='inline'
    }
    else{
        document.querySelector('.btn-info-sm-c').style.display='none'
        document.querySelector('.blogcontainer').style.display='none'
        setTimeout(()=>{
        document.querySelector('.cross-read').style.display='inline'
    },400);
    }
})